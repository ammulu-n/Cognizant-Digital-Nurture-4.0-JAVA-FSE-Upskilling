it contains core java files
