// Syntax, Data Types, and Operators
const eventName = "City Music Fest";
const eventDate = "2025-07-10";
let seats = 100;

console.log(`Event: ${eventName} | Date: ${eventDate} | Seats Available: ${seats}`);

seats--;
console.log(`Seats left after registration: ${seats}`);
